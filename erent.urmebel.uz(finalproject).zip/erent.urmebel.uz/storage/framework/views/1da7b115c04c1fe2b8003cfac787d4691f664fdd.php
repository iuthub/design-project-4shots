<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Register</div>
                <div ng-app="">
                    <div class="panel-body">
                        <form name = "myform" class="form-horizontal" method="POST" action="<?php echo e(route('register')); ?>">
                            <?php echo e(csrf_field()); ?>

                            
                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <label for="name" class="col-md-4 control-label">Name</label>
                                
                                <div class="col-md-6">
                                    <input id="name" type="text" class="form-control" name="name" ng-model="name"
                                    ng-pattern='/^[a-zA-Z!$#%]+$/' value="<?php echo e(old('name')); ?>"
                                    placeholder="Your name" required autofocus>
                                    <span ng-show="myform.name.$touched && myform.name.$error.required">The name is required.</span>
                                    <span ng-show="myform.name.$dirty && myform.name.$error.pattern"> Name is invalid. Type only english letters.</span>
                                    <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('number') ? ' has-error' : ''); ?>">
                                <label for="number" class="col-md-4 control-label">Phone number</label>
                                
                                <div class="col-md-6">
                                    <div class="input-group mb-2 mr-sm-2 mb-sm-0">
                                        <div class="input-group-addon">+998</div>
                                        <input id="number" type="text" class="form-control" name="number" ng-model="number"
                                        ng-pattern='/^[0-9]{2}[0-9]{3}[0-9]{4}$/' value="<?php echo e(old('number')); ?>"
                                    placeholder="(90) 900-90-90" required ></div>
                                    <span ng-show="myform.number.$touched && myform.number.$error.required">The phone number is required.</span>
                                    <span ng-show="myform.number.$dirty && myform.number.$error.pattern"> Phone number is invalid. Type only 9-digit number.</span>
                                    <?php if($errors->has('number')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('number')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <label for="email" class="col-md-4 control-label">E-Mail Address</label>
                                <div class="col-md-6">
                                    <input id="email" type="email" class="form-control" name="email" ng-model="email" value="<?php echo e(old('email')); ?>" placeholder="example@gmail.com" ng-pattern='/^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/' required>
                                    <span ng-show="myform.email.$touched && myform.email.$error.required">The email is required.</span>
                                    <span ng-show="myform.email.$dirty && myform.email.$error.pattern"> Email is invalid. Type in appropriate form.</span>
                                    <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <label for="password" class="col-md-4 control-label">Password</label>
                                <div class="col-md-6">
                                    <input id="password" type="password" class="form-control" name="password" ng-model="password" placeholder="Password" ng-minlength="6" required>
                                    <span ng-show="myform.password.$touched && myform.password.$error.required">The password is required.</span>
                                    <span ng-show="myform.password.$error.minlength">The password is too short</span>
                                    <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>
                                <div class="col-md-6">
                                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" ng-model="password_confirmation" placeholder="Confirm password" ng-minlength="6" ng-pattern="password" required>
                                    <span ng-show="myform.password_confirmation.$touched && myform.password_confirmation.$error.required">The password confirmation is required.</span>
                                    <span ng-show="myform.password_confirmation.$error.pattern">The confirmation password is incorrect.</span>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-4">
                                    <button type="submit" class="btn btn-primary">
                                    Register
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>